package com.example.pdfviewerapp
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pdfviewerapp.R

class MainActivity : AppCompatActivity() {

    private lateinit var pdfRenderer: PdfRenderer
    private lateinit var currentPage: PdfRenderer.Page
    private lateinit var parcelFileDescriptor: ParcelFileDescriptor
    private var pageIndex = 0

    private lateinit var pdfImageView: ImageView


    private lateinit var openPdfButton: Button
    private lateinit var prevButton: ImageButton
    private lateinit var nextButton: ImageButton
    private lateinit var zoomInButton: ImageButton
    private lateinit var zoomOutButton: ImageButton

    private var currentZoom = 1.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pdfImageView = findViewById(R.id.pdfImageView)
        prevButton = findViewById(R.id.prevButton)
        nextButton = findViewById(R.id.nextButton)
        openPdfButton = findViewById(R.id.openPdfButton)
        zoomInButton = findViewById(R.id.zoomInButton)
        zoomOutButton = findViewById(R.id.zoomOutButton)

        openPdfButton.setOnClickListener {
            openFilePicker()
        }

        prevButton.setOnClickListener {
            if (::pdfRenderer.isInitialized && pageIndex > 0) {
                pageIndex--
                showPage()
            }
        }

        nextButton.setOnClickListener {
            if (::pdfRenderer.isInitialized && pageIndex < pdfRenderer.pageCount - 1) {
                pageIndex++
                showPage()
            }
        }

        zoomInButton.setOnClickListener {
            if (currentZoom < 3.0f) { // Limit max zoom to 3x
                currentZoom += 0.2f
                applyZoom()
            }
        }

        zoomOutButton.setOnClickListener {
            if (currentZoom > 0.5f) { // Limit min zoom to 0.5x
                currentZoom -= 0.2f
                applyZoom()
            }
        }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/pdf"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                openPdfFromUri(uri)
            }
        } else {
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openPdfFromUri(uri: Uri) {
        try {
            if (::pdfRenderer.isInitialized) {
                pdfRenderer.close()
                parcelFileDescriptor.close()
            }
            parcelFileDescriptor = contentResolver.openFileDescriptor(uri, "r")!!
            pdfRenderer = PdfRenderer(parcelFileDescriptor)
            pageIndex = 0
            showPage()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to open PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showPage() {
        if (::currentPage.isInitialized) {
            currentPage.close()
        }

        currentPage = pdfRenderer.openPage(pageIndex)
        val bitmap = Bitmap.createBitmap(
            currentPage.width,
            currentPage.height,
            Bitmap.Config.ARGB_8888
        )
        currentPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        pdfImageView.setImageBitmap(bitmap)

        currentZoom = 1.0f // Reset zoom for a new page
        applyZoom()
    }

    private fun applyZoom() {
        val matrix = Matrix()
        matrix.postScale(currentZoom, currentZoom, pdfImageView.width / 2f, pdfImageView.height / 2f)
        pdfImageView.imageMatrix = matrix
        pdfImageView.scaleType = ImageView.ScaleType.MATRIX
        pdfImageView.invalidate()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::currentPage.isInitialized) currentPage.close()
        if (::pdfRenderer.isInitialized) pdfRenderer.close()
        if (::parcelFileDescriptor.isInitialized) parcelFileDescriptor.close()
    }
}
